const express = require('express')
const { sequelize, Users } = require('../models')
const path = require('path')
const usrMsgs = require('./routes/userMessages')

const route = express.Router()
const BP = require('body-parser')
const cors = require('cors');

const appCrud = express()

var corsOptions = {
    origin: 'http://localhost:8000',
    optionsSuccessStatus: 200
}
appCrud.use(cors(corsOptions));



appCrud.use(BP.urlencoded({extended: false}));
appCrud.use('/admin', BP.json());
appCrud.use('/admin', usrMsgs)





appCrud.listen({port: 9000}, async () => {
    await sequelize.authenticate()
})