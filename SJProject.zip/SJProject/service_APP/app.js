const express = require('express')
const { sequelize } = require('../models');
const path = require('path');
const app = express()
const cors = require('cors');
const jwt = require('jsonwebtoken');
const func = require('joi/lib/types/func');


var corsOptions = {
    origin: 'http://localhost:9000',
    optionsSuccessStatus: 200
}
app.use(cors(corsOptions));

function authToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    console.log(token)
    if (token == null)  return res.status(400).json({ msg: "Unauthorized"});
  
    jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
        console.log(err)
        if (err) return res.status(401).json({ msg: "Invalid token"});
        
        req.user = user;
    
        next();
    });
}




app.get('/register', (req, res) => {
    res.sendFile('register.html', { root: './service_APP/static' });
});

 app.get('/login', (req, res) => {
     res.sendFile('login.html', { root: './service_APP/static' });
 });

 app.get('/', (req, res) => {

    res.sendFile('login.html', { root: './service_APP/static' });
});


app.post('/',authToken, (req, res) => {

});

app.get('/moderator', (req, res) => {

    res.sendFile('indexModerator.html', { root: './service_APP/static' });
});


app.use(express.static(path.join(__dirname, 'static')));

app.listen({ port: 8000 }, async () => {
    console.log('Pokrenut je aplikacioni servis')
    await sequelize.authenticate();
});